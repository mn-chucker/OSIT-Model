#!/usr/bin/env python3
import concurrent.futures, json, os, socket, urllib.request
from datetime import datetime, timezone

BASE_DIR = os.path.expanduser("~/brand-monitor")
SEEN_FILE = os.path.join(BASE_DIR, "seen.json")
ALERT_LOG = os.path.join(BASE_DIR, "alerts.log")
ENV_FILE = os.path.join(BASE_DIR, ".env")

BRANDS = ["acmehealth", "acmepay", "acmecorp"]
LEGIT_DOMAINS = {"acmehealth.com", "acmepay.com", "acmecorp.com"}
TLDS = ["com", "net", "org", "co", "io", "info", "online", "support", "pay"]
LURES = ["", "-pay", "-portal", "-login", "-billing", "-support", "-secure", "pay", "portal"]

def get_discord_webhook():
    if not os.path.exists(ENV_FILE):
        return None
    with open(ENV_FILE) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                if "WEBHOOK_URL" in k.upper() and "discord.com/api/webhooks" in v:
                    return v.strip().strip('"').strip("'")
    return None

def send_discord_alert(webhook_url, alerts, ts):
    if not webhook_url or not alerts:
        return
    chunks = [alerts[i:i+15] for i in range(0, len(alerts), 15)]
    for idx, chunk in enumerate(chunks, 1):
        payload = {
            "username": "Brand & CT Monitor",
            "embeds": [{
                "title": f"New Brand / Lookalike Detections ({len(alerts)} total)",
                "description": "\n".join(f"• `{a}`" for a in chunk),
                "color": 15158332,
                "footer": {"text": f"{ts} | Batch {idx}/{len(chunks)}"}
            }]
        }
        req = urllib.request.Request(
            webhook_url,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json", "User-Agent": "BrandMonitor/1.0"}
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                resp.read()
        except Exception as e:
            print(f"Discord alert failed: {e}")

def is_legit(host):
    h = host.lower().strip().lstrip("*.")
    return any(h == d or h.endswith("." + d) for d in LEGIT_DOMAINS)

def query_ct(brand):
    found = []
    url = f"https://crt.sh{brand}%25&output=json"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "BrandMonitor/1.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            entries = json.loads(resp.read().decode("utf-8", errors="ignore"))
        for e in entries:
            for raw in e.get("name_value", "").splitlines():
                h = raw.strip().lower().lstrip("*.")
                if h and not is_legit(h):
                    found.append((f"ct:{h}", f"[CT-CERT] ({brand}) {h}"))
    except Exception:
        pass
    return found

def query_dns(host):
    try:
        _, _, ips = socket.gethostbyname_ex(host)
        if ips:
            return (f"dns:{host}", f"[DNS-LOOKALIKE] {host} -> {', '.join(ips)}")
    except Exception:
        pass
    return None

def main():
    first_run = not os.path.exists(SEEN_FILE)
    seen = set(json.load(open(SEEN_FILE))) if not first_run else set()
    alerts = []

    for b in BRANDS:
        for key, msg in query_ct(b):
            if key not in seen:
                seen.add(key)
                alerts.append(msg)

    candidates = sorted({
        f"{b}{l}.{t}" for b in BRANDS for l in LURES for t in TLDS
        if not is_legit(f"{b}{l}.{t}")
    })
    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as ex:
        for res in ex.map(query_dns, candidates):
            if res and res not in seen:
                seen.add(res)
                alerts.append(res)

    with open(SEEN_FILE, "w") as f:
        json.dump(sorted(seen), f, indent=2)

    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    if alerts:
        tag = "[BASELINE] " if first_run else ""
        with open(ALERT_LOG, "a") as f:
            for a in alerts:
                f.write(f"[{ts}] {tag}{a}\n")
        if not first_run:
            send_discord_alert(get_discord_webhook(), alerts, ts)
    print(f"[{ts}] Done. Tracked={len(seen)}, New={len(alerts)}")

if __name__ == "__main__":
    main()
