# Self-Hosted External Attack Surface & Threat Intel Lab

A lightweight, low-noise external monitoring stack designed to run alongside commercial security tools.

## Components
1. **`brand-monitor/monitor.py`** — Multi-threaded daily scanner checking Certificate Transparency logs (`crt.sh`) and DNS lookalike permutations for newly registered phishing/impersonation domains.
2. **`code-monitor/scan_code.py`** — Daily `TruffleHog --only-verified` scanner auditing public GitHub organizations and repositories referencing corporate domains, deduplicated by SHA-256 fingerprint.
3. **`easm-monitor/easm_diff.py`** — Stateful weekly `bbot` + `httpx` sweep diffing subdomains, live web endpoints, and HTTP status transitions (`200 -> 404` dangling CNAMEs) against a stored baseline.
4. **`mac-workstation/zshrc_helpers.zsh`** — SSH port-forwarding helpers and an isolated, DNS-leak-hardened Chrome profile routed over Tor SOCKS5.

## Quick Setup
1. Copy `.env.example` to `.env` inside each monitor directory and add your `ALERT_WEBHOOK_URL` and unscoped `GITHUB_TOKEN`.
2. Run each Python script once manually to generate its initial baseline (`seen.json`, `seen_secrets.json`, `baseline.json`) without alert spam.
3. Install the entries from `crontab.example` (`crontab -e`).
