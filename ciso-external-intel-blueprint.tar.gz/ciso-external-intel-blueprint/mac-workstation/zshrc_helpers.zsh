# Forward local ports over SSH to your intel worker VM (replace 10.0.0.10 with your VM IP)
ti() {
  pkill -f "127.0.0.1:8443:127.0.0.1:443" 2>/dev/null || true
  ssh -f -N -L 127.0.0.1:8443:127.0.0.1:443 -L 127.0.0.1:8787:127.0.0.1:8787 -L 127.0.0.1:9050:127.0.0.1:9050 analyst@10.0.0.10
  echo "Tunnels active: Threat Intel (https://127.0.0.1:8443) | Recon UI (http://127.0.0.1:8787) | Tor SOCKS (9050)"
}

# Launch an isolated Chrome profile locked to Tor SOCKS5 with local DNS fallback disabled
chrometor() {
  pgrep -f "127.0.0.1:9050:127.0.0.1:9050" >/dev/null || ssh -f -N -L 127.0.0.1:9050:127.0.0.1:9050 analyst@10.0.0.10
  open -na "Google Chrome" --args \
    --proxy-server="socks5://127.0.0.1:9050" \
    --host-resolver-rules="MAP * ~NOTFOUND , EXCLUDE 127.0.0.1" \
    --user-data-dir="$HOME/.chrome-tor-profile" \
    --no-first-run
}
