#!/usr/bin/env python3
import hashlib, json, os, subprocess, time, urllib.parse, urllib.request
from datetime import datetime, timezone

BASE_DIR = os.path.expanduser("~/code-monitor")
SEEN_FILE = os.path.join(BASE_DIR, "seen_secrets.json")
FINDINGS_LOG = os.path.join(BASE_DIR, "findings.log")
LOCAL_ENV = os.path.join(BASE_DIR, ".env")
TI_ENV = os.path.join(BASE_DIR, ".env")

DOMAINS = [
    "acmehealth.com",
    "acmepay.com",
    "acmecorp.com",
]

IGNORE_REPOS = {"8680/GOODBYEADS", "StevenBlack/hosts", "oisd-lists/oisd"}

def load_env_file(path):
    vals = {}
    if not os.path.exists(path):
        return vals
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                vals[k.strip()] = v.strip().strip('"').strip("'")
    return vals

def get_discord_webhook():
    env = load_env_file(TI_ENV)
    for k, v in env.items():
        if "WEBHOOK_URL" in k.upper() and "/api/webhooks/" in v:
            return v
    return None

def send_discord(webhook_url, alerts):
    if not webhook_url or not alerts:
        return
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    chunks = [alerts[i:i+10] for i in range(0, len(alerts), 10)]
    for idx, chunk in enumerate(chunks, 1):
        payload = {
            "username": "TruffleHog Code Leak Monitor",
            "embeds": [{
                "title": f"Verified Public Code Secret Alert ({len(alerts)} total)",
                "description": "\n".join(f"• {item}" for item in chunk),
                "color": 15158332,
                "footer": {"text": f"{ts} | Batch {idx}/{len(chunks)}"}
            }]
        }
        req = urllib.request.Request(
            webhook_url,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json", "User-Agent": "CodeMonitor/1.0"}
        )
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                resp.read()
        except Exception as e:
            print(f"Discord alert failed: {e}", flush=True)

def discover_domain_repos(gh_token):
    repos = set()
    if not gh_token:
        print("No GITHUB_TOKEN set in ~/code-monitor/.env; skipping GitHub Code Search API.", flush=True)
        return repos
    headers = {
        "Authorization": f"Bearer {gh_token}",
        "Accept": "application/vnd.github+json",
        "User-Agent": "CodeMonitor/1.0"
    }
    api_base = "".join(["https", chr(58), chr(47)*2, "api.", "github", ".com/search/code"])
    for dom in DOMAINS:
        q = urllib.parse.quote(f'"{dom}"')
        url = f"{api_base}?q={q}&per_page=20"
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read().decode("utf-8", errors="ignore"))
            for item in data.get("items", []):
                repo_obj = item.get("repository", {})
                full_name = repo_obj.get("full_name", "")
                html_url = repo_obj.get("html_url")
                if html_url and full_name not in IGNORE_REPOS and repo_obj.get("size", 0) < 15000:
                    repos.add(html_url)
        except Exception as e:
            print(f"GitHub search warning for {dom}: {e}", flush=True)
        time.sleep(2.5)
    return repos

def run_trufflehog(args, gh_token, timeout_sec=90):
    env = os.environ.copy()
    if gh_token:
        env["GITHUB_TOKEN"] = gh_token
    cmd = ["trufflehog"] + args + ["--only-verified", "--json", "--no-update"]
    try:
        res = subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=timeout_sec)
    except subprocess.TimeoutExpired:
        print(f"     [!] Timed out after {timeout_sec}s, skipping...", flush=True)
        return []
    findings = []
    for line in res.stdout.splitlines():
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            findings.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    return findings

def main():
    local_env = load_env_file(LOCAL_ENV)
    gh_token = local_env.get("GITHUB_TOKEN", "")
    orgs = [o.strip() for o in local_env.get("GITHUB_ORGS", "").split(",") if o.strip()]

    seen = set(json.load(open(SEEN_FILE))) if os.path.exists(SEEN_FILE) else set()
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    print(f"[{ts}] Starting TruffleHog code leak scan...", flush=True)

    raw_findings = []
    for org in orgs:
        print(f"  -> Scanning GitHub org: {org}", flush=True)
        raw_findings.extend(run_trufflehog(["github", f"--org={org}"], gh_token, timeout_sec=300))

    repos = sorted(discover_domain_repos(gh_token))
    print(f"  -> Discovered {len(repos)} public repos referencing corporate domains", flush=True)
    for repo_url in repos[:25]:
        print(f"  -> Scanning repo: {repo_url}", flush=True)
        raw_findings.extend(run_trufflehog(["git", repo_url, "--max-depth=1"], gh_token, timeout_sec=60))

    new_alerts = []
    for f in raw_findings:
        detector = f.get("DetectorName", "Unknown")
        meta = f.get("SourceMetadata", {}).get("Data", {})
        git_info = meta.get("Git", meta.get("Github", {}))
        repo = git_info.get("repository", "unknown-repo")
        file_path = git_info.get("file", "unknown-file")
        commit = str(git_info.get("commit", ""))[:10]
        raw_val = f.get("Raw", "")

        fp = hashlib.sha256(f"{detector}|{repo}|{file_path}|{raw_val}".encode()).hexdigest()
        if fp not in seen:
            seen.add(fp)
            masked = (raw_val[:4] + "..." + raw_val[-4:]) if len(raw_val) > 10 else "***"
            msg = f"**{detector}** (`{masked}`) in `{repo}` -> `{file_path}` (commit `{commit}`)"
            new_alerts.append(msg)

    with open(SEEN_FILE, "w") as out:
        json.dump(sorted(seen), out, indent=2)

    if new_alerts:
        with open(FINDINGS_LOG, "a") as logf:
            for a in new_alerts:
                logf.write(f"[{ts}] {a}\n")
        send_discord(get_discord_webhook(), new_alerts)
        print(f"[{ts}] Found {len(new_alerts)} NEW verified secrets! Sent Discord alert.", flush=True)
    else:
        print(f"[{ts}] Scan complete. Zero new verified secrets found.", flush=True)

if __name__ == "__main__":
    main()
