#!/usr/bin/env python3
import json, os, subprocess, urllib.request
from datetime import datetime, timezone

BASE_DIR = os.path.expanduser("~/easm-monitor")
STATE_FILE = os.path.join(BASE_DIR, "baseline.json")
HISTORY_LOG = os.path.join(BASE_DIR, "changes.log")
ARTEX_DIR = os.path.expanduser("~/artex")
ENV_FILE = os.path.join(BASE_DIR, ".env")

DOMAINS = [
    "acmehealth.com",
    "acmepay.com",
    "acmecorp.com",
]

def get_discord_webhook():
    if not os.path.exists(ENV_FILE):
        return None
    with open(ENV_FILE) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                if "WEBHOOK_URL" in k.upper() and "://discord.com" in v:
                    return v.strip().strip('"').strip("'")
    return None

def send_discord(webhook_url, title, lines, color=15105570):
    if not webhook_url or not lines:
        return
    chunks = [lines[i:i+15] for i in range(0, len(lines), 15)]
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    for idx, chunk in enumerate(chunks, 1):
        payload = {
            "username": "EASM Delta Monitor",
            "embeds": [{
                "title": f"{title} ({len(lines)} total)",
                "description": "\n".join(f"• {item}" for item in chunk),
                "color": color,
                "footer": {"text": f"{ts} | Batch {idx}/{len(chunks)}"}
            }]
        }
        req = urllib.request.Request(
            webhook_url,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json", "User-Agent": "EASMMonitor/1.0"}
        )
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                resp.read()
        except Exception as e:
            print(f"Discord notification failed: {e}", flush=True)

def sweep_domain(domain):
    escaped = domain.replace(".", "\\.")
    cmd = f"""
    WORK="/tmp/easm_$$"
    mkdir -p "$WORK"
    timeout -k 10 180 bbot -t {domain} -p subdomain-enum --flags passive --exclude-modules dnsbrute --yes -o "$WORK" -n scan >/dev/null 2>&1 || true
    grep -rhoE '[a-zA-Z0-9._-]+\\.{escaped}' "$WORK/scan/output.json" 2>/dev/null | grep -v '^-' | tr '[:upper:]' '[:lower:]' | sort -u > "$WORK/subs.txt"
    if [ -s "$WORK/subs.txt" ]; then
        httpx -l "$WORK/subs.txt" -sc -title -tech-detect -td -timeout 5 -retries 0 -rl 25 -silent -json -o "$WORK/httpx.json" >/dev/null 2>&1 || true
    fi
    echo "===SUBS==="
    cat "$WORK/subs.txt" 2>/dev/null || true
    echo "===HTTPX==="
    cat "$WORK/httpx.json" 2>/dev/null || true
    rm -rf "$WORK"
    """
    res = subprocess.run(
        ["docker", "compose", "exec", "-T", "artex", "bash", "-c", cmd],
        cwd=ARTEX_DIR,
        capture_output=True,
        text=True,
        timeout=900
    )
    subs, endpoints = set(), {}
    section = None
    for line in res.stdout.splitlines():
        if line == "===SUBS===":
            section = "subs"
            continue
        elif line == "===HTTPX===":
            section = "httpx"
            continue
        if section == "subs" and line.strip():
            subs.add(line.strip())
        elif section == "httpx" and line.strip():
            try:
                d = json.loads(line)
                url = d.get("url", "")
                if url:
                    endpoints[url] = {
                        "status": d.get("status_code", 0),
                        "title": (d.get("title") or "").strip()[:50],
                        "tech": ",".join(d.get("tech") or [])
                    }
            except json.JSONDecodeError:
                pass
    return subs, endpoints

def main():
    first_run = not os.path.exists(STATE_FILE)
    prev = json.load(open(STATE_FILE)) if not first_run else {"subdomains": [], "endpoints": {}}
    prev_subs = set(prev.get("subdomains", []))
    prev_eps = prev.get("endpoints", {})

    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    print(f"[{ts}] Starting per-domain EASM sweep across {len(DOMAINS)} domains...", flush=True)

    curr_subs, curr_eps = set(), {}
    for domain in DOMAINS:
        print(f"  -> Scanning {domain}...", flush=True)
        try:
            s, e = sweep_domain(domain)
            curr_subs.update(s)
            curr_eps.update(e)
            print(f"     {domain}: {len(s)} subdomains, {len(e)} live endpoints", flush=True)
        except Exception as err:
            print(f"     {domain}: failed ({err})", flush=True)

    new_subs = sorted(curr_subs - prev_subs)
    new_eps, status_changes = [], []

    for url, meta in sorted(curr_eps.items()):
        sig = f"`{url}` [**{meta['status']}**] {meta['title']} ({meta['tech']})"
        if url not in prev_eps:
            new_eps.append(sig)
        elif prev_eps[url].get("status") != meta["status"]:
            old_sc = prev_eps[url].get("status")
            status_changes.append(f"`{url}` shifted **{old_sc} → {meta['status']}** ({meta['title']})")

    with open(STATE_FILE, "w") as f:
        json.dump({
            "updated_at": ts,
            "subdomains": sorted(curr_subs),
            "endpoints": curr_eps
        }, f, indent=2)

    done_ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    print(f"[{done_ts}] Sweep complete: {len(curr_subs)} total subdomains, {len(curr_eps)} live endpoints.", flush=True)

    if first_run:
        print(f"[{done_ts}] Initial baseline saved to {STATE_FILE}.", flush=True)
        with open(HISTORY_LOG, "a") as f:
            f.write(f"[{done_ts}] BASELINE: {len(curr_subs)} subdomains, {len(curr_eps)} live endpoints\n")
        return

    webhook = get_discord_webhook()
    if new_subs:
        with open(HISTORY_LOG, "a") as f:
            for s in new_subs:
                f.write(f"[{done_ts}] NEW_SUBDOMAIN: {s}\n")
        send_discord(webhook, "EASM Alert: New Subdomains Discovered", [f"`{s}`" for s in new_subs], color=3447003)

    if new_eps:
        with open(HISTORY_LOG, "a") as f:
            for e in new_eps:
                f.write(f"[{done_ts}] NEW_ENDPOINT: {e}\n")
        send_discord(webhook, "EASM Alert: New Live Web Endpoints", new_eps, color=15158332)

    if status_changes:
        with open(HISTORY_LOG, "a") as f:
            for c in status_changes:
                f.write(f"[{done_ts}] STATUS_SHIFT: {c}\n")
        send_discord(webhook, "EASM Alert: Endpoint HTTP Status Changes", status_changes, color=15105570)

    if not (new_subs or new_eps or status_changes):
        print(f"[{done_ts}] No external attack surface changes detected.", flush=True)

if __name__ == "__main__":
    main()
